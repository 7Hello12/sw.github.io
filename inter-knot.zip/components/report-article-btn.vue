<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    @click="show = true"
  >
    <title>举报</title>
    <path
      d="M4.00001 20V14C4.00001 9.58172 7.58173 6 12 6C16.4183 6 20 9.58172 20 14V20H21V22H3.00001V20H4.00001ZM6.00001 20H18V14C18 10.6863 15.3137 8 12 8C8.6863 8 6.00001 10.6863 6.00001 14V20ZM11 2H13V5H11V2ZM19.7782 4.80761L21.1924 6.22183L19.0711 8.34315L17.6569 6.92893L19.7782 4.80761ZM2.80762 6.22183L4.22183 4.80761L6.34315 6.92893L4.92894 8.34315L2.80762 6.22183ZM7.00001 14C7.00001 11.2386 9.23858 9 12 9V11C10.3432 11 9.00001 12.3431 9.00001 14H7.00001Z"
    ></path>
  </svg>
  <popup-input-box
    :show="show"
    @close="show = false"
    @cancel="show = false"
    @submit="
      show = false;
      show2 = true;
    "
    v-model="text"
    title="举报原因"
    placeholder="请输入举报原因"
    :disabled="text.length === 0"
  />
  <popup-input-box
    :show="show2"
    @close="show2 = false"
    @cancel="show2 = false"
    @submit="reportArticle"
    v-model="text2"
    title="确定举报？"
    placeholder="请输入 yes 确定举报"
    :disabled="text2 !== 'yes'"
  />
</template>

<script lang="ts" setup>
const props = defineProps<{
  article: Article;
}>();

const store = useConfigStore();

const show = ref(false);
const show2 = ref(false);

const text = ref("");
const text2 = ref("");

let flag = false;
async function reportArticle() {
  show2.value = false;
  if (flag) return;
  flag = true;
  try {
    await addDiscussionComment(
      await getDiscussionId(store.reportNumber),
      `违规文章：#${props.article.number}\n违规原因：${text.value}`
    );
    useNuxtApp().$toast.success("举报成功");
  } catch (e) {
    console.error(e);
    useNuxtApp().$toast.error("举报失败");
  }
  flag = false;
}
</script>

<style scoped lang="less">
svg {
  width: 36px;
  height: 36px;
  cursor: pointer;
}
</style>
